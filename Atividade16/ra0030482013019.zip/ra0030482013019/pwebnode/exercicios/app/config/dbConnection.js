var sql = require('mssql/msnodesqlv8');

var connSQLServer = function () {
    console.log('Conexao com o banco de dados estabelecida!');

    const config = {
        user: 'BD2013019',
        password: 'Sorocaba1',
        database: 'BD',
        server: '192.168.1.6',
        driver: 'msnodesqlv8',
    }

    return sql.connect(config);
}
// exportando a função e quando chamar a página ele conecta 
module.exports = function () {
    console.log('O autoload carregou o módulo de conexão com o bd');
    return connSQLServer;
} 